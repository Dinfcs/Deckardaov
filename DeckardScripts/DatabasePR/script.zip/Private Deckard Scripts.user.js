// ==UserScript==
// @name        Private Deckard Scripts
// @namespace
// @version     2.5
// @description Several Tools implemented for improvements in the AM process, with manual update button on specific domain.
// @author      Luis E
// @match       *://*/*
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_deleteValue
// @grant       GM_listValues
// @grant       GM_xmlhttpRequest
// @grant       GM_addStyle
// @grant       GM_getResourceText
// @grant       GM_getResourceURL
// @grant       GM_registerMenuCommand
// @grant       GM_unregisterMenuCommand
// @grant       GM_openInTab
// @grant       GM_notification
// @grant       GM_setClipboard
// @grant       GM_download
// @grant       GM_log
// @grant       GM_info
// @grant       GM_getTab
// @grant       GM_getTabs
// @grant       GM_saveTab
// @grant       GM.setValue
// @grant       GM.getValue
// @grant       GM.deleteValue
// @grant       GM.listValues
// @updateURL   https://raw.githubusercontent.com/Dinfcs/Deckard/main/DeckardScripts/AuxiliarUpdate.js
// @downloadURL https://raw.githubusercontent.com/Dinfcs/Deckard/main/DeckardScripts/AuxiliarUpdate.js
// @icon        https://dinfcs.github.io/Deckardaov/logo.png
// ==/UserScript==

GM_addStyle(`
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .deckard-updater-button {
        position: fixed; bottom: 35px; left: 10px; z-index: 99999;
        background-color: #D1E231; color: #333; border: none;
        border-radius: 25%; width: 30px; height: 28px;
        display: flex; align-items: center; justify-content: center;
        transition: all 0.2s ease; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .deckard-updater-button:hover { background-color: #b8c52a; transform: scale(1.1); }
    .deckard-updater-button.updating { animation: spin 1s linear infinite; cursor: not-allowed; }
`);

const GH_TOKEN = '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';
const REPO_OWNER = 'Dinfcs';
const REPO_NAME = 'Deckard';
const PRINCIPAL_SCRIPT_PATH = 'DeckardScripts/Principal.js';

const PRINCIPAL_SCRIPT_URL = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${PRINCIPAL_SCRIPT_PATH}`;

const lastPrincipalUpdateKey = "lastPrincipalScriptUpdate";
const cachedPrincipalScriptKey = "cachedPrincipalScriptContent";

const shouldUpdatePrincipalScript = async () => {
    const lastUpdate = await GM.getValue(lastPrincipalUpdateKey, 0);
    return (Date.now() - lastUpdate) > 24 * 60 * 60 * 1000;
};

const clearAllScriptCaches = async () => {
    console.log('[Updater] Limpiando toda la caché de scripts...');
    try {
        const allKeys = await GM.listValues();
        const promises = [];
        const keysToDelete = [
            cachedPrincipalScriptKey,
            lastPrincipalUpdateKey,
            "lastUpdateScripts" // Clave usada por Principal.js
        ];

        for (const key of allKeys) {
            if (keysToDelete.includes(key) || key.startsWith('DeckardScripts/')) {
                console.log(`[Updater] Eliminando de la caché: ${key}`);
                promises.push(GM.deleteValue(key));
            }
        }
        await Promise.all(promises);
        console.log('[Updater] Limpieza de caché completada.');
    } catch (e) {
        console.error('[Updater] Error al limpiar la caché:', e);
    }
};

const fetchAndExecutePrincipalScript = async () => {
    return new Promise((resolve, reject) => {
        GM.xmlHttpRequest({
            method: "GET",
            url: PRINCIPAL_SCRIPT_URL,
            headers: { "Authorization": `token ${GH_TOKEN}`, "Accept": "application/vnd.github.v3.raw" },
            onload: async function(response) {
                if (response.status === 200) {
                    const scriptContent = response.responseText;
                    await GM.setValue(cachedPrincipalScriptKey, scriptContent);
                    await GM.setValue(lastPrincipalUpdateKey, Date.now());
                    console.log(`✅ Script Principal (${PRINCIPAL_SCRIPT_PATH}) descargado y/o actualizado.`);
                    try { eval(scriptContent); } catch (e) { console.error("Error al ejecutar script principal:", e); }
                    resolve();
                } else {
                    const errorMsg = `Error al cargar el Script Principal (${PRINCIPAL_SCRIPT_PATH}) - Status: ${response.status}`;
                    console.error(errorMsg);
                    reject(new Error(errorMsg));
                }
            },
            onerror: function(error) {
                console.error(`❌ Error de conexión al cargar el Script Principal (${PRINCIPAL_SCRIPT_PATH}):`, error);
                reject(error);
            }
        });
    });
};

const forceUpdateAndReload = async () => {
    const btn = document.getElementById('deckard-manual-updater');
    if (!btn) return;

    btn.disabled = true;
    btn.textContent = '⏳';
    btn.classList.add('updating');

    try {
        await clearAllScriptCaches();

        GM.notification({
            text: 'La caché de scripts ha sido limpiada. Recargue para obtener las últimas versiones.',
            title: 'Actualización Lista',
            timeout: 8000
        });

        if (confirm('Caché de scripts borrada.\n\n¿Desea recargar la página ahora para descargar las últimas versiones?')) {
            window.location.reload();
        }

    } catch (error) {
        console.error('Error durante el proceso de actualización forzada:', error);
        GM.notification({
            text: 'No se pudo limpiar la caché. Revise la consola para más detalles.',
            title: 'Error de Actualización',
            timeout: 8000
        });
    } finally {
        btn.disabled = false;
        btn.textContent = '🔄';
        btn.classList.remove('updating');
    }
};

(async function() {
    // --- INICIO DE LA MODIFICACIÓN ---
    // Solo mostrar el botón de actualización si estamos en el dominio correcto Y NO estamos en un iframe.
    if (window.location.hostname === 'cyborg.deckard.com' && window.top === window) {
        const updateButton = document.createElement('button');
        updateButton.id = 'deckard-manual-updater';
        updateButton.className = 'deckard-updater-button';
        updateButton.textContent = '🔄';
        updateButton.title = 'Force update of Lucho\'s Tools';
        updateButton.addEventListener('click', forceUpdateAndReload);
        document.body.appendChild(updateButton);
    }
    // --- FIN DE LA MODIFICACIÓN ---

    try {
        const cachedPrincipal = await GM.getValue(cachedPrincipalScriptKey);

        if (cachedPrincipal && !(await shouldUpdatePrincipalScript())) {
            eval(cachedPrincipal);
            console.log(`✅ Script Principal (${PRINCIPAL_SCRIPT_PATH}) cargado desde caché.`);
        } else {
            console.log(`🔄 Caché vacía o expirada. Buscando actualización para el Script Principal en GitHub...`);
            await fetchAndExecutePrincipalScript();
        }
    } catch (error) {
        console.error('❌ Error general en el cargador del Script Principal:', error);
        const cachedPrincipal = await GM.getValue(cachedPrincipalScriptKey);
        if (cachedPrincipal) {
            console.log("Intentando cargar la versión en caché del Script Principal debido a un error de conexión.");
            eval(cachedPrincipal);
        } else {
            console.error("No hay versión en caché del Script Principal disponible. El script no pudo ser cargado.");
        }
    }
})();